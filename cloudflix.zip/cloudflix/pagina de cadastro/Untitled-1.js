// Seletor do botão de assinatura
const assinaturaButton = document.getElementById('assinaturaButton');

// Adiciona um listener de evento de clique ao botão de assinatura
assinaturaButton.addEventListener('click', function() {
    // Aqui você pode adicionar a lógica para processar a assinatura, como enviar os dados para um servidor, etc.
    // Por enquanto, vamos apenas exibir uma mensagem de confirmação
    alert('Obrigado por se inscrever no Cloudflix! Você agora é um membro premium.');
});