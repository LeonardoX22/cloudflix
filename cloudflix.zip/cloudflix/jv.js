// Seletor do botão Google
const googleButton = document.getElementById('google-ios-button');

// Seletor do texto iOS
const iosText = document.getElementById('ios-option');

// Adiciona um listener de evento de clique ao botão Google
googleButton.addEventListener('click', function() {
    // Verifica se o texto atual do botão é "Entrar com Google"
    if (document.getElementById('login-title').textContent === 'Entrar com Google') {
        // Altera o título da caixa de entrada para "Entrar com iOS"
        document.getElementById('login-title').textContent = 'Entrar com iOS';
        // Exibe o texto de opção iOS
        iosText.style.display = 'block';
    } else {
        // Altera o título da caixa de entrada de volta para "Entrar com Google"
        document.getElementById('login-title').textContent = 'Entrar com Google';
        // Oculta o texto de opção iOS
        iosText.style.display = 'none';
    }
});

// Seletor do botão de login
const loginButton = document.getElementById('loginButton');

// Adiciona um listener de evento de clique ao botão de login
loginButton.addEventListener('click', function() {
    // Simula a verificação das credenciais (substitua este trecho pelo seu próprio código de verificação)
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;

    // Exemplo de verificação (substitua este trecho pelo seu próprio código de verificação)
    if (email === 'Brunoryangomes14@gmail.com' && password === 'Anab2108') {
        // Redireciona o usuário para a página principal (substitua 'pg.html' pelo nome da sua página principal)
        window.location.href = 'trabalhoUCB/pagina.html';
    } else {
        // Exibe uma mensagem de erro (opcional)
        alert('Credenciais inválidas. Por favor, tente novamente.');
    }
});